package com.riskradar;

import com.riskradar.agent.AgentOrchestrator;
import com.riskradar.dto.agent.AnalysisResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class AgentOrchestratorTest {
    @Autowired
    private AgentOrchestrator agentOrchestrator;

    @Test
    void shouldAnalyzeRiskQuestion() {
        AnalysisResponse response = agentOrchestrator.analyze("最近华东 APP 投诉为什么增加？");
        assertThat(response.traceId()).isNotBlank();
        assertThat(response.steps()).isNotEmpty();
        assertThat(response.reportMarkdown()).contains("RiskRadar 企业风险分析报告");
    }
}
