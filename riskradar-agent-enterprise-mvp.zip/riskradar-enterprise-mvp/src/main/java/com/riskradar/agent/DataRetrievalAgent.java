package com.riskradar.agent;

import com.riskradar.domain.RiskEvent;
import com.riskradar.repository.RiskEventRepository;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;

@Component
@Order(20)
public class DataRetrievalAgent implements Agent {
    private final RiskEventRepository riskEventRepository;

    public DataRetrievalAgent(RiskEventRepository riskEventRepository) {
        this.riskEventRepository = riskEventRepository;
    }

    @Override
    public String name() {
        return "DataRetrievalAgent";
    }

    @Override
    public void execute(AgentContext context) {
        String question = context.getQuestion().toLowerCase();
        List<RiskEvent> events = riskEventRepository.findByOccurredAtBetween(context.getStartTime(), context.getEndTime());
        List<RiskEvent> filtered = events.stream()
                .filter(e -> matchesIntent(question, context.getIntent(), e))
                .sorted(Comparator.comparing(RiskEvent::getOccurredAt).reversed())
                .limit(80)
                .toList();
        if (filtered.isEmpty()) {
            filtered = events.stream()
                    .sorted(Comparator.comparing(RiskEvent::getOccurredAt).reversed())
                    .limit(80)
                    .toList();
        }
        context.getEvents().addAll(filtered);
    }

    private boolean matchesIntent(String question, String intent, RiskEvent event) {
        String text = (event.getTitle() + " " + event.getContent() + " " + event.getRegion() + " "
                + event.getProductName() + " " + event.getChannel() + " " + event.getCategory().getLabel()).toLowerCase();
        if (question.contains("华东") && !event.getRegion().contains("华东")) return false;
        if (question.contains("华南") && !event.getRegion().contains("华南")) return false;
        if (question.contains("app") && !event.getChannel().equalsIgnoreCase("APP")) return false;
        return switch (intent) {
            case "SUPPLIER_RISK_ANALYSIS" -> event.getSupplierCode() != null || text.contains("供应") || text.contains("交付");
            case "PUBLIC_OPINION_ANALYSIS" -> text.contains("舆情") || text.contains("评论") || event.getSentimentScore() < -0.4;
            case "COMPLAINT_ANALYSIS" -> text.contains("投诉") || text.contains("客服");
            case "QUALITY_RISK_ANALYSIS" -> text.contains("质量") || text.contains("故障") || text.contains("缺陷");
            default -> true;
        };
    }
}
