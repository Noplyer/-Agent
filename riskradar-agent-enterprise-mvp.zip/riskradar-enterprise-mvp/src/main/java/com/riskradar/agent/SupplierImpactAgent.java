package com.riskradar.agent;

import com.riskradar.domain.RiskEvent;
import com.riskradar.dto.agent.RiskFinding;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@Order(50)
public class SupplierImpactAgent implements Agent {
    @Override
    public String name() {
        return "SupplierImpactAgent";
    }

    @Override
    public void execute(AgentContext context) {
        Map<String, List<RiskEvent>> bySupplier = context.getEvents().stream()
                .filter(e -> StringUtils.hasText(e.getSupplierCode()))
                .collect(Collectors.groupingBy(RiskEvent::getSupplierCode));
        bySupplier.entrySet().stream()
                .max((a, b) -> Integer.compare(score(a.getValue()), score(b.getValue())))
                .filter(e -> score(e.getValue()) >= 80)
                .ifPresent(e -> context.getFindings().add(new RiskFinding(
                        "供应商风险贡献明显",
                        score(e.getValue()) >= 130 ? "HIGH" : "MEDIUM",
                        "供应商",
                        e.getKey() + " 关联 " + e.getValue().size() + " 条事件，综合风险分 " + score(e.getValue()) + "。",
                        Math.min(100, score(e.getValue()))
                )));
    }

    private int score(List<RiskEvent> events) {
        return events.stream().mapToInt(e -> e.getSeverity().getWeight() * 10 + e.getImpactScore() / 4).sum();
    }
}
