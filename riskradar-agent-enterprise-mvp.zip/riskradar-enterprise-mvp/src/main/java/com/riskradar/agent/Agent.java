package com.riskradar.agent;

public interface Agent {
    String name();
    void execute(AgentContext context);
}
