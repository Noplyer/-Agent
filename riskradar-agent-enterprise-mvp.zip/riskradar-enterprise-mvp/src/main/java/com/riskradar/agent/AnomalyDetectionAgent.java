package com.riskradar.agent;

import com.riskradar.domain.RiskEvent;
import com.riskradar.domain.RiskSeverity;
import com.riskradar.dto.agent.RiskFinding;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@Order(30)
public class AnomalyDetectionAgent implements Agent {
    @Override
    public String name() {
        return "AnomalyDetectionAgent";
    }

    @Override
    public void execute(AgentContext context) {
        long total = context.getEvents().size();
        if (total == 0) {
            context.setRiskLevel("LOW");
            context.setSummary("当前时间范围内没有检索到风险事件，暂未发现明显风险。请扩大时间范围或接入更多数据源。");
            return;
        }

        long high = context.getEvents().stream()
                .filter(e -> e.getSeverity() == RiskSeverity.HIGH || e.getSeverity() == RiskSeverity.CRITICAL)
                .count();
        long negative = context.getEvents().stream().filter(e -> e.getSentimentScore() <= -0.55).count();
        double avgImpact = context.getEvents().stream().mapToInt(RiskEvent::getImpactScore).average().orElse(0);

        Map<LocalDate, Long> byDay = context.getEvents().stream()
                .collect(Collectors.groupingBy(e -> e.getOccurredAt().toLocalDate(), Collectors.counting()));
        double dailyAvg = byDay.values().stream().mapToLong(Long::longValue).average().orElse(0);
        byDay.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .filter(e -> e.getValue() >= Math.max(3, dailyAvg * 1.6))
                .ifPresent(e -> context.getFindings().add(new RiskFinding(
                        "风险事件出现异常集中",
                        high > 3 ? "HIGH" : "MEDIUM",
                        "时间维度",
                        e.getKey() + " 发生 " + e.getValue() + " 条相关事件，高于平均水平 " + String.format("%.1f", dailyAvg) + "。",
                        Math.min(100, (int) (e.getValue() * 15))
                )));

        if (negative >= Math.max(2, total * 0.35)) {
            context.getFindings().add(new RiskFinding(
                    "负面情绪占比偏高",
                    negative > total * 0.55 ? "HIGH" : "MEDIUM",
                    "情绪维度",
                    "负面情绪事件 " + negative + " 条，占比 " + String.format("%.0f%%", negative * 100.0 / total) + "。",
                    Math.min(100, (int) (negative * 100 / total))
            ));
        }

        if (avgImpact >= 70 || high >= 3) {
            context.getFindings().add(new RiskFinding(
                    "高影响风险需要优先处理",
                    avgImpact >= 80 || high >= 5 ? "CRITICAL" : "HIGH",
                    "影响范围",
                    "高等级事件 " + high + " 条，平均影响分 " + String.format("%.1f", avgImpact) + "。",
                    Math.min(100, (int) avgImpact)
            ));
        }

        context.getEvents().stream()
                .max(Comparator.comparingInt(RiskEvent::getImpactScore))
                .ifPresent(e -> context.getFindings().add(new RiskFinding(
                        "最高影响单点事件",
                        e.getSeverity().name(),
                        e.getCategory().getLabel(),
                        e.getTitle() + "，影响分 " + e.getImpactScore() + "，地区 " + e.getRegion() + "。",
                        e.getImpactScore()
                )));

        int maxScore = context.getFindings().stream().mapToInt(RiskFinding::score).max().orElse(0);
        if (maxScore >= 85 || context.getFindings().stream().anyMatch(f -> "CRITICAL".equals(f.level()))) {
            context.setRiskLevel("CRITICAL");
        } else if (maxScore >= 70 || high >= 3) {
            context.setRiskLevel("HIGH");
        } else if (maxScore >= 45 || !context.getFindings().isEmpty()) {
            context.setRiskLevel("MEDIUM");
        } else {
            context.setRiskLevel("LOW");
        }
    }
}
