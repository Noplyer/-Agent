package com.riskradar.agent;

import com.riskradar.dto.agent.Recommendation;
import com.riskradar.dto.agent.RiskFinding;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
@Order(70)
public class ReportWriterAgent implements Agent {
    @Override
    public String name() {
        return "ReportWriterAgent";
    }

    @Override
    public void execute(AgentContext context) {
        String summary = buildSummary(context);
        context.setSummary(summary);
        context.setMarkdownReport(buildMarkdown(context, summary));
    }

    private String buildSummary(AgentContext context) {
        if (context.getEvents().isEmpty()) {
            return "未检索到足够数据，建议扩大时间范围或检查数据接入链路。";
        }
        String firstFinding = context.getFindings().isEmpty() ? "暂未发现明显集中风险" : context.getFindings().get(0).title();
        return "本次共分析 " + context.getEvents().size() + " 条风险事件，综合风险等级为 "
                + context.getRiskLevel() + "。核心判断：" + firstFinding + "。";
    }

    private String buildMarkdown(AgentContext context, String summary) {
        StringBuilder sb = new StringBuilder();
        sb.append("# RiskRadar 企业风险分析报告\n\n");
        sb.append("生成时间：").append(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))).append("\n\n");
        sb.append("## 1. 用户问题\n\n").append(context.getQuestion()).append("\n\n");
        sb.append("## 2. 综合结论\n\n").append(summary).append("\n\n");
        sb.append("- 分析意图：").append(context.getIntent()).append("\n");
        sb.append("- 风险等级：").append(context.getRiskLevel()).append("\n");
        sb.append("- 数据范围：").append(context.getStartTime()).append(" ~ ").append(context.getEndTime()).append("\n\n");

        sb.append("## 3. 关键发现\n\n");
        if (context.getFindings().isEmpty()) {
            sb.append("暂无明显异常发现。\n");
        } else {
            for (RiskFinding finding : context.getFindings()) {
                sb.append("- 【").append(finding.level()).append("】")
                        .append(finding.title()).append("：")
                        .append(finding.evidence()).append("\n");
            }
        }

        sb.append("\n## 4. 处理建议\n\n");
        for (Recommendation recommendation : context.getRecommendations()) {
            sb.append("- 【").append(recommendation.priority()).append("】")
                    .append(recommendation.action())
                    .append(" 负责人：").append(recommendation.owner())
                    .append("。原因：").append(recommendation.reason()).append("\n");
        }

        sb.append("\n## 5. Agent 执行链路\n\n");
        context.getSteps().forEach(step -> sb.append("- ").append(step.agentName())
                .append("，耗时 ").append(step.costMillis()).append(" ms\n"));
        return sb.toString();
    }
}
