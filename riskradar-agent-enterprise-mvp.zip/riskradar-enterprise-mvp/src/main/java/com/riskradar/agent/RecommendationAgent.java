package com.riskradar.agent;

import com.riskradar.dto.agent.Recommendation;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(60)
public class RecommendationAgent implements Agent {
    @Override
    public String name() {
        return "RecommendationAgent";
    }

    @Override
    public void execute(AgentContext context) {
        String intent = context.getIntent();
        String level = context.getRiskLevel();

        if ("CRITICAL".equals(level) || "HIGH".equals(level)) {
            context.getRecommendations().add(new Recommendation(
                    "建立 24 小时专项跟踪群，按小时更新风险处理进展。",
                    "运营负责人",
                    "P0",
                    "当前存在高影响或集中爆发风险，需要快速收敛影响范围。"
            ));
        }

        if (intent.contains("PUBLIC_OPINION")) {
            context.getRecommendations().add(new Recommendation(
                    "对负面评论高频关键词进行聚类，发布统一口径说明并安排客服回访。",
                    "品牌公关/客服团队",
                    "P1",
                    "舆情类风险需要先降低用户不确定感，再处理根因。"
            ));
        }

        if (intent.contains("SUPPLIER")) {
            context.getRecommendations().add(new Recommendation(
                    "对高风险供应商执行交付复盘，检查备选供应商库存和交付能力。",
                    "供应链团队",
                    "P1",
                    "供应链风险一旦扩散，会影响订单履约和用户体验。"
            ));
        }

        if (intent.contains("COMPLAINT")) {
            context.getRecommendations().add(new Recommendation(
                    "按地区、产品和渠道拆分投诉工单，优先处理高影响用户群。",
                    "客服运营团队",
                    "P1",
                    "投诉风险需要通过工单闭环减少重复投诉。"
            ));
        }

        if (intent.contains("QUALITY")) {
            context.getRecommendations().add(new Recommendation(
                    "暂停问题批次推广，补充质量抽检并追踪缺陷复现路径。",
                    "产品质量团队",
                    "P1",
                    "质量类风险应优先阻断新增影响。"
            ));
        }

        context.getRecommendations().add(new Recommendation(
                "沉淀风险指标看板：负面率、投诉量、高危事件数、供应商风险分。",
                "数据团队",
                "P2",
                "将本次分析规则固化为监控指标，形成长期预警能力。"
        ));
    }
}
