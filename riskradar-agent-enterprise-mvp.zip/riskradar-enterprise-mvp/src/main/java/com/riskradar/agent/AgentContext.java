package com.riskradar.agent;

import com.riskradar.domain.RiskEvent;
import com.riskradar.dto.agent.AgentStepResponse;
import com.riskradar.dto.agent.Recommendation;
import com.riskradar.dto.agent.RiskFinding;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AgentContext {
    private final String traceId = UUID.randomUUID().toString();
    private final String question;
    private String intent = "GENERAL_RISK_ANALYSIS";
    private LocalDateTime startTime = LocalDateTime.now().minusDays(7);
    private LocalDateTime endTime = LocalDateTime.now().plusMinutes(1);
    private final List<String> keywords = new ArrayList<>();
    private final List<RiskEvent> events = new ArrayList<>();
    private final List<RiskFinding> findings = new ArrayList<>();
    private final List<Recommendation> recommendations = new ArrayList<>();
    private final List<AgentStepResponse> steps = new ArrayList<>();
    private String riskLevel = "LOW";
    private String summary = "暂无明显风险。";
    private String markdownReport = "";

    public AgentContext(String question) {
        this.question = question;
    }

    public String getTraceId() { return traceId; }
    public String getQuestion() { return question; }
    public String getIntent() { return intent; }
    public void setIntent(String intent) { this.intent = intent; }
    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }
    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }
    public List<String> getKeywords() { return keywords; }
    public List<RiskEvent> getEvents() { return events; }
    public List<RiskFinding> getFindings() { return findings; }
    public List<Recommendation> getRecommendations() { return recommendations; }
    public List<AgentStepResponse> getSteps() { return steps; }
    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }
    public String getSummary() { return summary; }
    public void setSummary(String summary) { this.summary = summary; }
    public String getMarkdownReport() { return markdownReport; }
    public void setMarkdownReport(String markdownReport) { this.markdownReport = markdownReport; }
}
