package com.riskradar.agent;

import com.riskradar.domain.RiskEvent;
import com.riskradar.dto.agent.RiskFinding;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@Order(40)
public class RootCauseAnalysisAgent implements Agent {
    @Override
    public String name() {
        return "RootCauseAnalysisAgent";
    }

    @Override
    public void execute(AgentContext context) {
        if (context.getEvents().isEmpty()) return;
        addTopDimension(context, "风险类型", e -> e.getCategory().getLabel());
        addTopDimension(context, "地区", RiskEvent::getRegion);
        addTopDimension(context, "产品", RiskEvent::getProductName);
        addTopDimension(context, "渠道", RiskEvent::getChannel);
    }

    private void addTopDimension(AgentContext context, String dimension, Function<RiskEvent, String> classifier) {
        Map<String, Long> group = context.getEvents().stream()
                .collect(Collectors.groupingBy(classifier, Collectors.counting()));
        group.entrySet().stream().max(Map.Entry.comparingByValue()).ifPresent(top -> {
            long total = context.getEvents().size();
            double ratio = top.getValue() * 1.0 / total;
            if (ratio >= 0.35 && top.getValue() >= 2) {
                context.getFindings().add(new RiskFinding(
                        dimension + "集中度较高",
                        ratio >= 0.55 ? "HIGH" : "MEDIUM",
                        dimension,
                        top.getKey() + " 贡献了 " + top.getValue() + " 条事件，占比 " + String.format("%.0f%%", ratio * 100) + "，可能是主要归因方向。",
                        Math.min(100, (int) (ratio * 100))
                ));
            }
        });
    }
}
