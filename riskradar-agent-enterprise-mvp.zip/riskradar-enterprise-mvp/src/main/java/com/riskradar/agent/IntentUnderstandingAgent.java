package com.riskradar.agent;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Component
@Order(10)
public class IntentUnderstandingAgent implements Agent {
    @Override
    public String name() {
        return "IntentUnderstandingAgent";
    }

    @Override
    public void execute(AgentContext context) {
        String q = context.getQuestion().toLowerCase();
        if (containsAny(q, "供应商", "交付", "供应链")) {
            context.setIntent("SUPPLIER_RISK_ANALYSIS");
        } else if (containsAny(q, "舆情", "负面", "评论", "口碑")) {
            context.setIntent("PUBLIC_OPINION_ANALYSIS");
        } else if (containsAny(q, "投诉", "客服")) {
            context.setIntent("COMPLAINT_ANALYSIS");
        } else if (containsAny(q, "质量", "故障", "缺陷")) {
            context.setIntent("QUALITY_RISK_ANALYSIS");
        } else if (containsAny(q, "报告", "周报", "总结")) {
            context.setIntent("RISK_REPORT_GENERATION");
        }

        if (containsAny(q, "今天")) {
            context.setStartTime(LocalDate.now().atStartOfDay());
        } else if (containsAny(q, "昨天")) {
            context.setStartTime(LocalDate.now().minusDays(1).atStartOfDay());
            context.setEndTime(LocalDate.now().atStartOfDay());
        } else if (containsAny(q, "本周", "这周", "最近一周")) {
            context.setStartTime(LocalDate.now().minusDays(7).atStartOfDay());
        } else if (containsAny(q, "本月", "最近一个月", "近30天")) {
            context.setStartTime(LocalDate.now().minusDays(30).atStartOfDay());
        }

        extractKeywords(q, context);
    }

    private boolean containsAny(String text, String... words) {
        for (String word : words) {
            if (text.contains(word)) return true;
        }
        return false;
    }

    private void extractKeywords(String q, AgentContext context) {
        List<String> candidates = List.of("华东", "华南", "华北", "APP", "小程序", "官网", "会员", "支付", "物流", "供应商", "投诉", "质量", "舆情");
        for (String candidate : candidates) {
            if (q.contains(candidate.toLowerCase())) {
                context.getKeywords().add(candidate);
            }
        }
    }
}
