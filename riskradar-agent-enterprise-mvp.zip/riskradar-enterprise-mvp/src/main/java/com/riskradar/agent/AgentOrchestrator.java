package com.riskradar.agent;

import com.riskradar.dto.agent.AgentStepResponse;
import com.riskradar.dto.agent.AnalysisResponse;
import com.riskradar.dto.risk.RiskEventResponse;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;

@Service
public class AgentOrchestrator {
    private final List<Agent> agents;

    public AgentOrchestrator(List<Agent> agents) {
        this.agents = agents;
    }

    @Transactional(readOnly = true)
    public AnalysisResponse analyze(String question) {
        AgentContext context = new AgentContext(question);
        for (Agent agent : agents) {
            long start = System.currentTimeMillis();
            String before = snapshot(context);
            agent.execute(context);
            long cost = System.currentTimeMillis() - start;
            context.getSteps().add(new AgentStepResponse(agent.name(), before, snapshot(context), cost));
        }
        List<RiskEventResponse> evidence = context.getEvents().stream()
                .sorted(Comparator.comparingInt(e -> -e.getImpactScore()))
                .limit(8)
                .map(RiskEventResponse::from)
                .toList();
        return new AnalysisResponse(
                context.getTraceId(),
                context.getQuestion(),
                context.getIntent(),
                context.getRiskLevel(),
                context.getSummary(),
                context.getSteps(),
                context.getFindings(),
                context.getRecommendations(),
                context.getMarkdownReport(),
                evidence
        );
    }

    private String snapshot(AgentContext context) {
        return "intent=" + context.getIntent()
                + ", events=" + context.getEvents().size()
                + ", findings=" + context.getFindings().size()
                + ", riskLevel=" + context.getRiskLevel();
    }
}
