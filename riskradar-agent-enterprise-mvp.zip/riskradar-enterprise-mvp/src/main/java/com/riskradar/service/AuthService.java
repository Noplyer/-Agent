package com.riskradar.service;

import com.riskradar.common.BusinessException;
import com.riskradar.domain.AppUser;
import com.riskradar.dto.auth.LoginRequest;
import com.riskradar.dto.auth.LoginResponse;
import com.riskradar.dto.auth.RegisterRequest;
import com.riskradar.repository.AppUserRepository;
import com.riskradar.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
    private final AppUserRepository appUserRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(AppUserRepository appUserRepository, PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.appUserRepository = appUserRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    public LoginResponse login(LoginRequest request) {
        AppUser user = appUserRepository.findByUsername(request.username())
                .orElseThrow(() -> new BusinessException("LOGIN_FAILED", "用户名或密码错误"));
        if (!user.isEnabled() || !passwordEncoder.matches(request.password(), user.getPassword())) {
            throw new BusinessException("LOGIN_FAILED", "用户名或密码错误");
        }
        String token = jwtService.generateToken(user.getUsername(), user.getRole());
        return new LoginResponse(token, "Bearer", user.getUsername(), user.getDisplayName(), user.getRole());
    }

    @Transactional
    public LoginResponse register(RegisterRequest request) {
        if (appUserRepository.existsByUsername(request.username())) {
            throw new BusinessException("USERNAME_EXISTS", "用户名已存在");
        }
        AppUser user = new AppUser();
        user.setUsername(request.username());
        user.setPassword(passwordEncoder.encode(request.password()));
        user.setDisplayName(request.displayName());
        user.setRole("ROLE_ANALYST");
        user.setEnabled(true);
        appUserRepository.save(user);
        String token = jwtService.generateToken(user.getUsername(), user.getRole());
        return new LoginResponse(token, "Bearer", user.getUsername(), user.getDisplayName(), user.getRole());
    }
}
