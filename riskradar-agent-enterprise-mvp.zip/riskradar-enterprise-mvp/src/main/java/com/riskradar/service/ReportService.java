package com.riskradar.service;

import com.riskradar.agent.AgentOrchestrator;
import com.riskradar.domain.AnalysisReport;
import com.riskradar.dto.agent.AnalysisResponse;
import com.riskradar.dto.report.ReportResponse;
import com.riskradar.repository.AnalysisReportRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class ReportService {
    private final AgentOrchestrator agentOrchestrator;
    private final AnalysisReportRepository reportRepository;

    public ReportService(AgentOrchestrator agentOrchestrator, AnalysisReportRepository reportRepository) {
        this.agentOrchestrator = agentOrchestrator;
        this.reportRepository = reportRepository;
    }

    @Transactional
    public ReportResponse generate(String question) {
        AnalysisResponse analysis = agentOrchestrator.analyze(question);
        AnalysisReport report = new AnalysisReport();
        report.setTitle("企业风险分析报告 - " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmm")));
        report.setQuestion(question);
        report.setRiskLevel(analysis.riskLevel());
        report.setSummary(analysis.summary());
        report.setMarkdownContent(analysis.reportMarkdown());
        return ReportResponse.from(reportRepository.save(report));
    }

    @Transactional(readOnly = true)
    public List<ReportResponse> latest() {
        return reportRepository.findTop10ByOrderByCreatedAtDesc().stream()
                .map(ReportResponse::from)
                .toList();
    }
}
