package com.riskradar.service;

import com.riskradar.common.BusinessException;
import com.riskradar.domain.*;
import com.riskradar.dto.risk.RiskEventCreateRequest;
import com.riskradar.dto.risk.RiskEventResponse;
import com.riskradar.repository.RiskEventRepository;
import jakarta.persistence.criteria.Predicate;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class RiskEventService {
    private final RiskEventRepository riskEventRepository;

    public RiskEventService(RiskEventRepository riskEventRepository) {
        this.riskEventRepository = riskEventRepository;
    }

    @Transactional
    @CacheEvict(cacheNames = {"dashboard", "supplier-risk"}, allEntries = true)
    public RiskEventResponse create(RiskEventCreateRequest request) {
        RiskEvent event = new RiskEvent();
        event.setTitle(request.title());
        event.setContent(request.content());
        event.setSource(request.source());
        event.setCategory(request.category());
        event.setSeverity(request.severity());
        event.setOccurredAt(request.occurredAt() == null ? LocalDateTime.now() : request.occurredAt());
        event.setRegion(request.region());
        event.setProductName(request.productName());
        event.setChannel(request.channel());
        event.setSupplierCode(request.supplierCode());
        event.setSentimentScore(request.sentimentScore());
        event.setImpactScore(request.impactScore());
        event.setStatus(EventStatus.OPEN);
        return RiskEventResponse.from(riskEventRepository.save(event));
    }

    @Transactional(readOnly = true)
    public RiskEventResponse get(Long id) {
        return riskEventRepository.findById(id)
                .map(RiskEventResponse::from)
                .orElseThrow(() -> new BusinessException("RISK_EVENT_NOT_FOUND", "风险事件不存在"));
    }

    @Transactional(readOnly = true)
    public Page<RiskEventResponse> search(String keyword,
                                          RiskCategory category,
                                          RiskSeverity severity,
                                          EventStatus status,
                                          String region,
                                          LocalDateTime start,
                                          LocalDateTime end,
                                          Pageable pageable) {
        Specification<RiskEvent> specification = (root, query, builder) -> {
            List<Predicate> predicates = new ArrayList<>();
            if (StringUtils.hasText(keyword)) {
                String like = "%" + keyword.trim().toLowerCase() + "%";
                predicates.add(builder.or(
                        builder.like(builder.lower(root.get("title")), like),
                        builder.like(builder.lower(root.get("content")), like),
                        builder.like(builder.lower(root.get("productName")), like),
                        builder.like(builder.lower(root.get("channel")), like)
                ));
            }
            if (category != null) predicates.add(builder.equal(root.get("category"), category));
            if (severity != null) predicates.add(builder.equal(root.get("severity"), severity));
            if (status != null) predicates.add(builder.equal(root.get("status"), status));
            if (StringUtils.hasText(region)) predicates.add(builder.equal(root.get("region"), region));
            if (start != null) predicates.add(builder.greaterThanOrEqualTo(root.get("occurredAt"), start));
            if (end != null) predicates.add(builder.lessThanOrEqualTo(root.get("occurredAt"), end));
            return builder.and(predicates.toArray(Predicate[]::new));
        };
        return riskEventRepository.findAll(specification, pageable).map(RiskEventResponse::from);
    }
}
