package com.riskradar.service;

import com.riskradar.dto.ingestion.IngestionResponse;
import com.riskradar.dto.ingestion.RiskEventBatchIngestRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class IngestionService {
    private final RiskEventService riskEventService;

    public IngestionService(RiskEventService riskEventService) {
        this.riskEventService = riskEventService;
    }

    @Transactional
    public IngestionResponse ingest(RiskEventBatchIngestRequest request) {
        request.events().forEach(riskEventService::create);
        return new IngestionResponse(request.events().size(), 0, "批量风险事件接入成功");
    }
}
