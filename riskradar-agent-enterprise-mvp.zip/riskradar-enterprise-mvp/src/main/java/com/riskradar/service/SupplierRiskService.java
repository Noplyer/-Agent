package com.riskradar.service;

import com.riskradar.domain.RiskEvent;
import com.riskradar.domain.RiskSeverity;
import com.riskradar.domain.Supplier;
import com.riskradar.dto.risk.SupplierRiskResponse;
import com.riskradar.repository.RiskEventRepository;
import com.riskradar.repository.SupplierRepository;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SupplierRiskService {
    private final SupplierRepository supplierRepository;
    private final RiskEventRepository riskEventRepository;

    public SupplierRiskService(SupplierRepository supplierRepository, RiskEventRepository riskEventRepository) {
        this.supplierRepository = supplierRepository;
        this.riskEventRepository = riskEventRepository;
    }

    @Transactional(readOnly = true)
    @Cacheable(cacheNames = "supplier-risk")
    public List<SupplierRiskResponse> listSupplierRisk() {
        List<Supplier> suppliers = supplierRepository.findAll();
        List<RiskEvent> events = riskEventRepository.findByOccurredAtBetween(
                LocalDate.now().minusDays(30).atStartOfDay(),
                LocalDate.now().plusDays(1).atStartOfDay()
        );
        Map<String, List<RiskEvent>> bySupplier = events.stream()
                .filter(e -> e.getSupplierCode() != null && !e.getSupplierCode().isBlank())
                .collect(Collectors.groupingBy(RiskEvent::getSupplierCode));

        return suppliers.stream()
                .map(s -> buildRiskResponse(s, bySupplier.getOrDefault(s.getSupplierCode(), List.of())))
                .sorted(Comparator.comparingInt(SupplierRiskResponse::riskScore).reversed())
                .toList();
    }

    private SupplierRiskResponse buildRiskResponse(Supplier supplier, List<RiskEvent> events) {
        long highRisk = events.stream().filter(e -> e.getSeverity() == RiskSeverity.HIGH || e.getSeverity() == RiskSeverity.CRITICAL).count();
        int eventScore = events.stream().mapToInt(e -> e.getSeverity().getWeight() * 10 + e.getImpactScore() / 5).sum();
        int deliveryPenalty = (int) Math.max(0, (0.95 - supplier.getOnTimeDeliveryRate()) * 120);
        int qualityPenalty = Math.max(0, 90 - supplier.getQualityScore());
        int score = Math.min(100, eventScore + deliveryPenalty + qualityPenalty);
        String level = score >= 75 ? "CRITICAL" : score >= 55 ? "HIGH" : score >= 30 ? "MEDIUM" : "LOW";
        String advice = switch (level) {
            case "CRITICAL" -> "立即启动供应商专项复盘，暂停新增采购，准备备选供应商。";
            case "HIGH" -> "要求供应商提交整改计划，并提高抽检和交付监控频率。";
            case "MEDIUM" -> "持续跟踪交付与质量指标，设置预警阈值。";
            default -> "保持常规监控。";
        };
        return new SupplierRiskResponse(
                supplier.getSupplierCode(), supplier.getName(), supplier.getRegion(), supplier.getLevel(),
                supplier.getOnTimeDeliveryRate(), supplier.getQualityScore(), events.size(), highRisk,
                score, level, advice
        );
    }
}
