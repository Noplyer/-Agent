package com.riskradar.service;

import com.riskradar.domain.RiskEvent;
import com.riskradar.domain.RiskSeverity;
import com.riskradar.dto.risk.DashboardSummaryResponse;
import com.riskradar.dto.risk.RiskEventResponse;
import com.riskradar.repository.RiskEventRepository;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class DashboardService {
    private final RiskEventRepository riskEventRepository;

    public DashboardService(RiskEventRepository riskEventRepository) {
        this.riskEventRepository = riskEventRepository;
    }

    @Transactional(readOnly = true)
    @Cacheable(cacheNames = "dashboard")
    public DashboardSummaryResponse summary() {
        LocalDateTime start = LocalDate.now().minusDays(14).atStartOfDay();
        LocalDateTime end = LocalDateTime.now().plusMinutes(1);
        List<RiskEvent> events = riskEventRepository.findByOccurredAtBetween(start, end);

        long total = events.size();
        long high = events.stream().filter(e -> e.getSeverity() == RiskSeverity.HIGH || e.getSeverity() == RiskSeverity.CRITICAL).count();
        long open = events.stream().filter(e -> "OPEN".equals(e.getStatus().name())).count();
        long negative = events.stream().filter(e -> e.getSentimentScore() <= -0.45).count();
        double avgImpact = events.stream().mapToInt(RiskEvent::getImpactScore).average().orElse(0.0);

        Map<String, Long> categoryDistribution = events.stream().collect(Collectors.groupingBy(e -> e.getCategory().getLabel(), Collectors.counting()));
        String topCategory = topKey(categoryDistribution);
        Map<String, Long> regions = events.stream().collect(Collectors.groupingBy(RiskEvent::getRegion, Collectors.counting()));
        String topRegion = topKey(regions);

        Map<String, Long> trendByDay = new LinkedHashMap<>();
        for (int i = 6; i >= 0; i--) {
            LocalDate day = LocalDate.now().minusDays(i);
            trendByDay.put(day.toString(), 0L);
        }
        events.stream()
                .filter(e -> !e.getOccurredAt().toLocalDate().isBefore(LocalDate.now().minusDays(6)))
                .collect(Collectors.groupingBy(e -> e.getOccurredAt().toLocalDate().toString(), Collectors.counting()))
                .forEach(trendByDay::put);

        List<RiskEventResponse> latest = events.stream()
                .sorted(Comparator.comparing(RiskEvent::getOccurredAt).reversed())
                .limit(8)
                .map(RiskEventResponse::from)
                .toList();

        return new DashboardSummaryResponse(total, high, open, negative, topCategory, topRegion, avgImpact,
                trendByDay, categoryDistribution, latest);
    }

    private String topKey(Map<String, Long> map) {
        return map.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("暂无");
    }
}
