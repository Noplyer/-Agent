package com.riskradar.repository;

import com.riskradar.domain.RiskEvent;
import com.riskradar.domain.RiskSeverity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

public interface RiskEventRepository extends JpaRepository<RiskEvent, Long>, JpaSpecificationExecutor<RiskEvent> {
    List<RiskEvent> findByOccurredAtBetween(LocalDateTime start, LocalDateTime end);
    long countByOccurredAtBetween(LocalDateTime start, LocalDateTime end);
    long countBySeverityInAndOccurredAtBetween(Collection<RiskSeverity> severities, LocalDateTime start, LocalDateTime end);
    List<RiskEvent> findTop8ByOrderByOccurredAtDesc();
}
