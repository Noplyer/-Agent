package com.riskradar.repository;

import com.riskradar.domain.AnalysisReport;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AnalysisReportRepository extends JpaRepository<AnalysisReport, Long> {
    List<AnalysisReport> findTop10ByOrderByCreatedAtDesc();
}
