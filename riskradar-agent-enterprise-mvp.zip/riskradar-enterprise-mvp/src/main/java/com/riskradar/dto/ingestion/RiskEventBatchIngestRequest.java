package com.riskradar.dto.ingestion;

import com.riskradar.dto.risk.RiskEventCreateRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;

import java.util.List;

public record RiskEventBatchIngestRequest(
        @NotEmpty(message = "批量事件不能为空") List<@Valid RiskEventCreateRequest> events
) {}
