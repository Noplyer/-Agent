package com.riskradar.dto.agent;

public record RiskFinding(
        String title,
        String level,
        String dimension,
        String evidence,
        int score
) {}
