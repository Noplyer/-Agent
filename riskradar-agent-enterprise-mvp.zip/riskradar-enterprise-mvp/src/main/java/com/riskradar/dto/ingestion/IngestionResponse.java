package com.riskradar.dto.ingestion;

public record IngestionResponse(
        int accepted,
        int rejected,
        String message
) {}
