package com.riskradar.dto.report;

import com.riskradar.domain.AnalysisReport;

import java.time.LocalDateTime;

public record ReportResponse(
        Long id,
        String title,
        String question,
        String riskLevel,
        String summary,
        String markdownContent,
        LocalDateTime createdAt
) {
    public static ReportResponse from(AnalysisReport report) {
        return new ReportResponse(
                report.getId(),
                report.getTitle(),
                report.getQuestion(),
                report.getRiskLevel(),
                report.getSummary(),
                report.getMarkdownContent(),
                report.getCreatedAt()
        );
    }
}
