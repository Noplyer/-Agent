package com.riskradar.dto.auth;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record RegisterRequest(
        @NotBlank(message = "用户名不能为空") @Size(min = 3, max = 30) String username,
        @NotBlank(message = "密码不能为空") @Size(min = 6, max = 50) String password,
        @NotBlank(message = "展示名称不能为空") String displayName
) {}
