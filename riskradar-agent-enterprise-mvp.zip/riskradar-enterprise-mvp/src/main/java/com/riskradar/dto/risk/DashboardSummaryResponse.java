package com.riskradar.dto.risk;

import java.util.List;
import java.util.Map;

public record DashboardSummaryResponse(
        long totalEvents,
        long highRiskEvents,
        long openEvents,
        long negativeEvents,
        String topCategory,
        String topRegion,
        double averageImpactScore,
        Map<String, Long> trendByDay,
        Map<String, Long> categoryDistribution,
        List<RiskEventResponse> latestEvents
) {}
