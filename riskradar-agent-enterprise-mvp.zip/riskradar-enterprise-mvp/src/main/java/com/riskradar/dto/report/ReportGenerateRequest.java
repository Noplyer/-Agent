package com.riskradar.dto.report;

import jakarta.validation.constraints.NotBlank;

public record ReportGenerateRequest(@NotBlank(message = "问题不能为空") String question) {}
