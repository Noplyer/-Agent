package com.riskradar.dto.risk;

import com.riskradar.domain.RiskCategory;
import com.riskradar.domain.RiskSeverity;
import jakarta.validation.constraints.*;

import java.time.LocalDateTime;

public record RiskEventCreateRequest(
        @NotBlank(message = "标题不能为空") String title,
        @NotBlank(message = "内容不能为空") String content,
        @NotBlank(message = "来源不能为空") String source,
        @NotNull(message = "风险类型不能为空") RiskCategory category,
        @NotNull(message = "风险等级不能为空") RiskSeverity severity,
        LocalDateTime occurredAt,
        @NotBlank(message = "地区不能为空") String region,
        @NotBlank(message = "产品不能为空") String productName,
        @NotBlank(message = "渠道不能为空") String channel,
        String supplierCode,
        @DecimalMin(value = "-1.0", message = "情绪分必须 >= -1") @DecimalMax(value = "1.0", message = "情绪分必须 <= 1") double sentimentScore,
        @Min(value = 0, message = "影响分必须 >= 0") @Max(value = 100, message = "影响分必须 <= 100") int impactScore
) {}
