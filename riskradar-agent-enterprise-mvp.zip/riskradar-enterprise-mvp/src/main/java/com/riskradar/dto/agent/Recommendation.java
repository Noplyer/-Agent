package com.riskradar.dto.agent;

public record Recommendation(
        String action,
        String owner,
        String priority,
        String reason
) {}
