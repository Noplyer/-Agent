package com.riskradar.dto.risk;

public record SupplierRiskResponse(
        String supplierCode,
        String supplierName,
        String region,
        String level,
        double onTimeDeliveryRate,
        int qualityScore,
        long relatedEvents,
        long highRiskEvents,
        int riskScore,
        String riskLevel,
        String advice
) {}
