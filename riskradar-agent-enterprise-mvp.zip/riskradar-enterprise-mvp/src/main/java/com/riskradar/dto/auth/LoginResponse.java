package com.riskradar.dto.auth;

public record LoginResponse(
        String token,
        String tokenType,
        String username,
        String displayName,
        String role
) {}
