package com.riskradar.dto.agent;

import com.riskradar.dto.risk.RiskEventResponse;

import java.util.List;

public record AnalysisResponse(
        String traceId,
        String question,
        String intent,
        String riskLevel,
        String summary,
        List<AgentStepResponse> steps,
        List<RiskFinding> findings,
        List<Recommendation> recommendations,
        String reportMarkdown,
        List<RiskEventResponse> evidenceEvents
) {}
