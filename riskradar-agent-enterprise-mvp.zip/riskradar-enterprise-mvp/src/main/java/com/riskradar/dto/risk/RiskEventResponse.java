package com.riskradar.dto.risk;

import com.riskradar.domain.EventStatus;
import com.riskradar.domain.RiskCategory;
import com.riskradar.domain.RiskEvent;
import com.riskradar.domain.RiskSeverity;

import java.time.LocalDateTime;

public record RiskEventResponse(
        Long id,
        String title,
        String content,
        String source,
        RiskCategory category,
        String categoryLabel,
        RiskSeverity severity,
        String severityLabel,
        EventStatus status,
        LocalDateTime occurredAt,
        String region,
        String productName,
        String channel,
        String supplierCode,
        double sentimentScore,
        int impactScore
) {
    public static RiskEventResponse from(RiskEvent event) {
        return new RiskEventResponse(
                event.getId(),
                event.getTitle(),
                event.getContent(),
                event.getSource(),
                event.getCategory(),
                event.getCategory().getLabel(),
                event.getSeverity(),
                event.getSeverity().getLabel(),
                event.getStatus(),
                event.getOccurredAt(),
                event.getRegion(),
                event.getProductName(),
                event.getChannel(),
                event.getSupplierCode(),
                event.getSentimentScore(),
                event.getImpactScore()
        );
    }
}
