package com.riskradar.dto.agent;

public record AgentStepResponse(
        String agentName,
        String input,
        String output,
        long costMillis
) {}
