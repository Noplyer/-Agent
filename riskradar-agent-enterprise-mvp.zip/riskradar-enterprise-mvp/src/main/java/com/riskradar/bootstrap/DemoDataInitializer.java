package com.riskradar.bootstrap;

import com.riskradar.domain.*;
import com.riskradar.repository.AppUserRepository;
import com.riskradar.repository.RiskEventRepository;
import com.riskradar.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

@Component
public class DemoDataInitializer implements CommandLineRunner {
    private final AppUserRepository userRepository;
    private final SupplierRepository supplierRepository;
    private final RiskEventRepository riskEventRepository;
    private final PasswordEncoder passwordEncoder;
    private final boolean initData;

    public DemoDataInitializer(AppUserRepository userRepository,
                               SupplierRepository supplierRepository,
                               RiskEventRepository riskEventRepository,
                               PasswordEncoder passwordEncoder,
                               @Value("${riskradar.demo.init-data:true}") boolean initData) {
        this.userRepository = userRepository;
        this.supplierRepository = supplierRepository;
        this.riskEventRepository = riskEventRepository;
        this.passwordEncoder = passwordEncoder;
        this.initData = initData;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (!initData) return;
        initUsers();
        initSuppliers();
        initRiskEvents();
    }

    private void initUsers() {
        if (!userRepository.existsByUsername("admin")) {
            AppUser admin = new AppUser();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setDisplayName("系统管理员");
            admin.setRole("ROLE_ADMIN");
            admin.setEnabled(true);
            userRepository.save(admin);
        }
        if (!userRepository.existsByUsername("analyst")) {
            AppUser analyst = new AppUser();
            analyst.setUsername("analyst");
            analyst.setPassword(passwordEncoder.encode("analyst123"));
            analyst.setDisplayName("风险分析员");
            analyst.setRole("ROLE_ANALYST");
            analyst.setEnabled(true);
            userRepository.save(analyst);
        }
    }

    private void initSuppliers() {
        if (supplierRepository.count() > 0) return;
        supplierRepository.saveAll(List.of(
                supplier("SUP-001", "星河物流", "华东", "A", 0.86, 82, "近期华东仓履约波动"),
                supplier("SUP-002", "青云包装", "华南", "B", 0.94, 88, "包装质量稳定"),
                supplier("SUP-003", "北辰电子", "华北", "A", 0.91, 76, "电子配件返修率偏高"),
                supplier("SUP-004", "海川仓配", "西南", "B", 0.97, 91, "稳定供应商"),
                supplier("SUP-005", "启明材料", "华东", "C", 0.79, 69, "需要重点跟踪")
        ));
    }

    private Supplier supplier(String code, String name, String region, String level, double deliveryRate, int qualityScore, String remark) {
        Supplier supplier = new Supplier();
        supplier.setSupplierCode(code);
        supplier.setName(name);
        supplier.setRegion(region);
        supplier.setLevel(level);
        supplier.setOnTimeDeliveryRate(deliveryRate);
        supplier.setQualityScore(qualityScore);
        supplier.setRemark(remark);
        return supplier;
    }

    private void initRiskEvents() {
        if (riskEventRepository.count() > 0) return;
        Random random = new Random(20260509L);
        String[] regions = {"华东", "华南", "华北", "西南"};
        String[] products = {"会员服务", "智能硬件", "支付服务", "物流服务", "企业套餐"};
        String[] channels = {"APP", "小程序", "官网", "客服中心", "社交媒体"};
        String[] suppliers = {"SUP-001", "SUP-002", "SUP-003", "SUP-004", "SUP-005", null};

        for (int day = 13; day >= 0; day--) {
            int base = day <= 3 ? 6 : 3;
            for (int i = 0; i < base + random.nextInt(3); i++) {
                RiskEvent event = new RiskEvent();
                RiskCategory category = randomCategory(random, day);
                RiskSeverity severity = randomSeverity(random, day);
                String region = day <= 3 && random.nextBoolean() ? "华东" : regions[random.nextInt(regions.length)];
                String product = day <= 4 && random.nextBoolean() ? "会员服务" : products[random.nextInt(products.length)];
                String channel = random.nextBoolean() ? "APP" : channels[random.nextInt(channels.length)];
                String supplier = random.nextInt(10) < 5 ? suppliers[random.nextInt(suppliers.length)] : null;
                event.setTitle(title(category, region, product));
                event.setContent(content(category, region, product));
                event.setSource(source(category));
                event.setCategory(category);
                event.setSeverity(severity);
                event.setStatus(random.nextInt(10) < 6 ? EventStatus.OPEN : EventStatus.PROCESSING);
                event.setOccurredAt(LocalDateTime.now().minusDays(day).minusHours(random.nextInt(12)).minusMinutes(random.nextInt(60)));
                event.setRegion(region);
                event.setProductName(product);
                event.setChannel(channel);
                event.setSupplierCode(supplier);
                event.setSentimentScore(sentiment(category, severity, random));
                event.setImpactScore(Math.min(100, severity.getWeight() * 18 + random.nextInt(30) + (day <= 3 ? 10 : 0)));
                riskEventRepository.save(event);
            }
        }

        addHotspot("华东会员服务负面评论集中上升", "社交媒体中出现会员续费、权益不清晰等负面讨论，转发量明显增加。",
                RiskCategory.PUBLIC_OPINION, RiskSeverity.HIGH, "华东", "会员服务", "社交媒体", null, -0.88, 91, 1);
        addHotspot("华东 APP 投诉量异常增加", "用户集中反馈 APP 支付后权益到账延迟，客服响应慢。",
                RiskCategory.COMPLAINT, RiskSeverity.CRITICAL, "华东", "会员服务", "APP", null, -0.91, 96, 0);
        addHotspot("星河物流华东仓交付延迟", "SUP-001 关联订单出现延迟，影响会员礼品履约体验。",
                RiskCategory.SUPPLY_CHAIN, RiskSeverity.HIGH, "华东", "物流服务", "客服中心", "SUP-001", -0.62, 87, 2);
        addHotspot("启明材料质检不通过率上升", "SUP-005 最近一批材料抽检发现稳定性问题，需要暂停入库。",
                RiskCategory.PRODUCT_QUALITY, RiskSeverity.HIGH, "华东", "智能硬件", "供应链系统", "SUP-005", -0.58, 84, 3);
    }

    private RiskCategory randomCategory(Random random, int day) {
        if (day <= 4 && random.nextInt(10) < 6) {
            return List.of(RiskCategory.PUBLIC_OPINION, RiskCategory.COMPLAINT, RiskCategory.SUPPLY_CHAIN).get(random.nextInt(3));
        }
        RiskCategory[] values = RiskCategory.values();
        return values[random.nextInt(values.length)];
    }

    private RiskSeverity randomSeverity(Random random, int day) {
        if (day <= 4 && random.nextBoolean()) return RiskSeverity.HIGH;
        RiskSeverity[] values = {RiskSeverity.LOW, RiskSeverity.MEDIUM, RiskSeverity.HIGH};
        return values[random.nextInt(values.length)];
    }

    private String title(RiskCategory category, String region, String product) {
        return switch (category) {
            case PUBLIC_OPINION -> region + product + "出现负面舆情讨论";
            case COMPLAINT -> region + product + "用户投诉增加";
            case SUPPLY_CHAIN -> region + product + "供应链交付波动";
            case PRODUCT_QUALITY -> product + "质量反馈异常";
            case POLICY -> region + "政策合规提醒";
            case SECURITY -> product + "出现安全告警";
            case OPERATION -> region + product + "运营指标波动";
        };
    }

    private String content(RiskCategory category, String region, String product) {
        return switch (category) {
            case PUBLIC_OPINION -> "多平台评论提到" + product + "体验下降，集中地区为" + region + "。";
            case COMPLAINT -> "客服工单显示" + region + "用户对" + product + "反馈较多，要求尽快处理。";
            case SUPPLY_CHAIN -> "供应商交付节奏不稳定，可能影响" + product + "履约。";
            case PRODUCT_QUALITY -> "抽检和售后反馈显示" + product + "存在质量波动。";
            case POLICY -> "新的监管要求可能影响" + region + "相关业务流程。";
            case SECURITY -> product + "相关接口出现异常访问，需要安全排查。";
            case OPERATION -> product + "转化率和活跃度出现异常变化。";
        };
    }

    private String source(RiskCategory category) {
        return switch (category) {
            case PUBLIC_OPINION -> "social-listening";
            case COMPLAINT -> "complaint-center";
            case SUPPLY_CHAIN -> "supply-chain-system";
            case PRODUCT_QUALITY -> "quality-inspection";
            case POLICY -> "policy-monitor";
            case SECURITY -> "security-center";
            case OPERATION -> "operation-bi";
        };
    }

    private double sentiment(RiskCategory category, RiskSeverity severity, Random random) {
        double base = switch (category) {
            case PUBLIC_OPINION, COMPLAINT -> -0.65;
            case SUPPLY_CHAIN, PRODUCT_QUALITY -> -0.45;
            default -> -0.15;
        };
        base -= severity.getWeight() * 0.06;
        base += random.nextDouble() * 0.3;
        return Math.max(-1, Math.min(1, Math.round(base * 100.0) / 100.0));
    }

    private void addHotspot(String title, String content, RiskCategory category, RiskSeverity severity,
                            String region, String product, String channel, String supplierCode,
                            double sentiment, int impact, int daysAgo) {
        RiskEvent event = new RiskEvent();
        event.setTitle(title);
        event.setContent(content);
        event.setCategory(category);
        event.setSeverity(severity);
        event.setStatus(EventStatus.OPEN);
        event.setRegion(region);
        event.setProductName(product);
        event.setChannel(channel);
        event.setSupplierCode(supplierCode);
        event.setSentimentScore(sentiment);
        event.setImpactScore(impact);
        event.setSource(source(category));
        event.setOccurredAt(LocalDateTime.now().minusDays(daysAgo).minusHours(2));
        riskEventRepository.save(event);
    }
}
