package com.riskradar.domain;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "risk_events", indexes = {
        @Index(name = "idx_risk_event_occurred", columnList = "occurredAt"),
        @Index(name = "idx_risk_event_category", columnList = "category"),
        @Index(name = "idx_risk_event_severity", columnList = "severity"),
        @Index(name = "idx_risk_event_supplier", columnList = "supplierCode")
})
public class RiskEvent extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    private String title;

    @Column(nullable = false, length = 1000)
    private String content;

    @Column(nullable = false, length = 60)
    private String source;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 40)
    private RiskCategory category;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private RiskSeverity severity;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private EventStatus status = EventStatus.OPEN;

    @Column(nullable = false)
    private LocalDateTime occurredAt;

    @Column(nullable = false, length = 40)
    private String region;

    @Column(nullable = false, length = 80)
    private String productName;

    @Column(nullable = false, length = 40)
    private String channel;

    @Column(length = 40)
    private String supplierCode;

    @Column(nullable = false)
    private double sentimentScore;

    @Column(nullable = false)
    private int impactScore;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
    public RiskCategory getCategory() { return category; }
    public void setCategory(RiskCategory category) { this.category = category; }
    public RiskSeverity getSeverity() { return severity; }
    public void setSeverity(RiskSeverity severity) { this.severity = severity; }
    public EventStatus getStatus() { return status; }
    public void setStatus(EventStatus status) { this.status = status; }
    public LocalDateTime getOccurredAt() { return occurredAt; }
    public void setOccurredAt(LocalDateTime occurredAt) { this.occurredAt = occurredAt; }
    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }
    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    public String getChannel() { return channel; }
    public void setChannel(String channel) { this.channel = channel; }
    public String getSupplierCode() { return supplierCode; }
    public void setSupplierCode(String supplierCode) { this.supplierCode = supplierCode; }
    public double getSentimentScore() { return sentimentScore; }
    public void setSentimentScore(double sentimentScore) { this.sentimentScore = sentimentScore; }
    public int getImpactScore() { return impactScore; }
    public void setImpactScore(int impactScore) { this.impactScore = impactScore; }
}
