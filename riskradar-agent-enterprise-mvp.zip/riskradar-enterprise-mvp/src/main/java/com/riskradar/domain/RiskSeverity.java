package com.riskradar.domain;

public enum RiskSeverity {
    LOW(1, "低"), MEDIUM(2, "中"), HIGH(3, "高"), CRITICAL(4, "严重");
    private final int weight;
    private final String label;
    RiskSeverity(int weight, String label) {
        this.weight = weight;
        this.label = label;
    }
    public int getWeight() { return weight; }
    public String getLabel() { return label; }
}
