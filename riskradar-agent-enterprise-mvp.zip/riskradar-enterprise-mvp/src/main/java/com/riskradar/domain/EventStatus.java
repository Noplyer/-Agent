package com.riskradar.domain;

public enum EventStatus {
    OPEN, PROCESSING, CLOSED
}
