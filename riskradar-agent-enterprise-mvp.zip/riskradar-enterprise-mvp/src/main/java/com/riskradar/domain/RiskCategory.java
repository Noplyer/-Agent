package com.riskradar.domain;

public enum RiskCategory {
    PUBLIC_OPINION("舆情风险"),
    COMPLAINT("投诉风险"),
    SUPPLY_CHAIN("供应链风险"),
    PRODUCT_QUALITY("产品质量风险"),
    POLICY("政策合规风险"),
    SECURITY("安全风险"),
    OPERATION("运营风险");

    private final String label;
    RiskCategory(String label) { this.label = label; }
    public String getLabel() { return label; }
}
