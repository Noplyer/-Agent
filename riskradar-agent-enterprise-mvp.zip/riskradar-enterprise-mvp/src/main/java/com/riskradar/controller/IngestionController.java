package com.riskradar.controller;

import com.riskradar.common.ApiResponse;
import com.riskradar.dto.ingestion.IngestionResponse;
import com.riskradar.dto.ingestion.RiskEventBatchIngestRequest;
import com.riskradar.service.IngestionService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ingestion")
public class IngestionController {
    private final IngestionService ingestionService;

    public IngestionController(IngestionService ingestionService) {
        this.ingestionService = ingestionService;
    }

    @PostMapping("/risk-events/batch")
    public ApiResponse<IngestionResponse> batchIngest(@RequestBody @Valid RiskEventBatchIngestRequest request) {
        return ApiResponse.ok(ingestionService.ingest(request));
    }
}
