package com.riskradar.controller;

import com.riskradar.common.ApiResponse;
import com.riskradar.dto.risk.SupplierRiskResponse;
import com.riskradar.service.SupplierRiskService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/suppliers")
public class SupplierController {
    private final SupplierRiskService supplierRiskService;

    public SupplierController(SupplierRiskService supplierRiskService) {
        this.supplierRiskService = supplierRiskService;
    }

    @GetMapping("/risk-ranking")
    public ApiResponse<List<SupplierRiskResponse>> riskRanking() {
        return ApiResponse.ok(supplierRiskService.listSupplierRisk());
    }
}
