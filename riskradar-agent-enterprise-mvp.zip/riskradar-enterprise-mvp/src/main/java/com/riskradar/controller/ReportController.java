package com.riskradar.controller;

import com.riskradar.common.ApiResponse;
import com.riskradar.dto.report.ReportGenerateRequest;
import com.riskradar.dto.report.ReportResponse;
import com.riskradar.service.ReportService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reports")
public class ReportController {
    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @PostMapping("/generate")
    public ApiResponse<ReportResponse> generate(@RequestBody @Valid ReportGenerateRequest request) {
        return ApiResponse.ok("报告生成成功", reportService.generate(request.question()));
    }

    @GetMapping("/latest")
    public ApiResponse<List<ReportResponse>> latest() {
        return ApiResponse.ok(reportService.latest());
    }
}
