package com.riskradar.controller;

import com.riskradar.common.ApiResponse;
import com.riskradar.dto.auth.LoginRequest;
import com.riskradar.dto.auth.LoginResponse;
import com.riskradar.dto.auth.RegisterRequest;
import com.riskradar.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ApiResponse<LoginResponse> login(@RequestBody @Valid LoginRequest request) {
        return ApiResponse.ok(authService.login(request));
    }

    @PostMapping("/register")
    public ApiResponse<LoginResponse> register(@RequestBody @Valid RegisterRequest request) {
        return ApiResponse.ok("注册成功", authService.register(request));
    }
}
