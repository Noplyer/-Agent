package com.riskradar.controller;

import com.riskradar.agent.AgentOrchestrator;
import com.riskradar.common.ApiResponse;
import com.riskradar.dto.agent.AnalysisRequest;
import com.riskradar.dto.agent.AnalysisResponse;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/agent")
public class AgentController {
    private final AgentOrchestrator agentOrchestrator;

    public AgentController(AgentOrchestrator agentOrchestrator) {
        this.agentOrchestrator = agentOrchestrator;
    }

    @PostMapping("/analyze")
    public ApiResponse<AnalysisResponse> analyze(@RequestBody @Valid AnalysisRequest request) {
        return ApiResponse.ok(agentOrchestrator.analyze(request.question()));
    }
}
