package com.riskradar.controller;

import com.riskradar.common.ApiResponse;
import com.riskradar.common.PageResponse;
import com.riskradar.domain.EventStatus;
import com.riskradar.domain.RiskCategory;
import com.riskradar.domain.RiskSeverity;
import com.riskradar.dto.risk.RiskEventCreateRequest;
import com.riskradar.dto.risk.RiskEventResponse;
import com.riskradar.service.RiskEventService;
import jakarta.validation.Valid;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/risk-events")
public class RiskEventController {
    private final RiskEventService riskEventService;

    public RiskEventController(RiskEventService riskEventService) {
        this.riskEventService = riskEventService;
    }

    @PostMapping
    public ApiResponse<RiskEventResponse> create(@RequestBody @Valid RiskEventCreateRequest request) {
        return ApiResponse.ok("风险事件创建成功", riskEventService.create(request));
    }

    @GetMapping("/{id}")
    public ApiResponse<RiskEventResponse> get(@PathVariable Long id) {
        return ApiResponse.ok(riskEventService.get(id));
    }

    @GetMapping
    public ApiResponse<PageResponse<RiskEventResponse>> search(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) RiskCategory category,
            @RequestParam(required = false) RiskSeverity severity,
            @RequestParam(required = false) EventStatus status,
            @RequestParam(required = false) String region,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime end,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        Pageable pageable = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 50), Sort.by(Sort.Direction.DESC, "occurredAt"));
        return ApiResponse.ok(PageResponse.from(riskEventService.search(keyword, category, severity, status, region, start, end, pageable)));
    }
}
