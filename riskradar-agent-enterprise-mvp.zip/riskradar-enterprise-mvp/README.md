# RiskRadar Agent Enterprise MVP

**RiskRadar Agent** 是一个完整可运行的“企业风险预警 + 舆情洞察 + 多 Agent 协作”MVP。它不是简单聊天机器人，而是模拟企业数据分析师的工作流：自然语言问题 -> 意图理解 -> 数据检索 -> 异常检测 -> 多维归因 -> 供应商影响评估 -> 处理建议 -> 自动报告。

## 技术栈

- Spring Boot 3.3.5
- Spring MVC
- Spring Security + JWT
- Spring Data JPA
- H2 内存数据库，开箱即用
- PostgreSQL profile，可用 docker-compose 切换
- Validation 参数校验
- Actuator 监控
- Spring Cache 简单缓存
- 原生 HTML/CSS/JS 可视化页面

## 快速启动

要求：JDK 17+、Maven 3.8+

```bash
cd riskradar-enterprise-mvp
mvn spring-boot:run
```

打开：

```text
http://localhost:8080
```

默认账号：

```text
admin / admin123
analyst / analyst123
```

H2 控制台：

```text
http://localhost:8080/h2-console
JDBC URL: jdbc:h2:mem:riskradar
User: sa
Password: 空
```

## Docker PostgreSQL 模式

```bash
docker compose up -d postgres
mvn spring-boot:run -Dspring-boot.run.profiles=postgres
```

## 核心功能

1. 登录鉴权：JWT + Spring Security。
2. 风险事件管理：新增、分页、筛选、详情查询。
3. 风险看板：近 14 天总风险、高危事件、未关闭事件、负面情绪事件。
4. 供应商风险排行：结合交付率、质量分、关联风险事件计算风险等级。
5. 多 Agent 分析：自动理解问题、检索数据、识别异常、归因、生成建议。
6. 自动报告：生成并保存 Markdown 风险报告。
7. 企业级基础：统一响应、统一异常、参数校验、分层架构、测试样例。

## 多 Agent 链路

- IntentUnderstandingAgent：识别用户问题、时间范围、分析意图。
- DataRetrievalAgent：从风险事件库检索相关数据。
- AnomalyDetectionAgent：识别异常集中、负面情绪、高影响事件。
- RootCauseAnalysisAgent：按风险类型、地区、产品、渠道归因。
- SupplierImpactAgent：识别供应商风险贡献。
- RecommendationAgent：生成处理建议和负责人建议。
- ReportWriterAgent：生成结构化 Markdown 报告。

## API 示例

登录：

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'
```

多 Agent 分析：

```bash
curl -X POST http://localhost:8080/api/agent/analyze \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{"question":"最近平台负面舆情为什么上升？请分析原因并给出处理建议"}'
```

生成报告：

```bash
curl -X POST http://localhost:8080/api/reports/generate \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{"question":"生成本周企业风险分析报告"}'
```

## 项目结构

```text
src/main/java/com/riskradar
├── agent          多 Agent 编排链路
├── bootstrap      初始化演示数据
├── common         统一响应与异常
├── config         安全与缓存配置
├── controller     API 控制器
├── domain         JPA 实体和枚举
├── dto            请求/响应对象
├── repository     数据访问层
├── security       JWT 与用户认证
└── service        业务服务层
```

## 可直接填写到申请表的项目描述

我构建了一个多 Agent 协作的企业风险预警与舆情洞察平台 RiskRadar Agent，主要解决传统企业数据系统只能被动查看报表、无法主动发现风险和解释原因的问题。项目面向企业运营、供应链管理和品牌舆情监控场景，接入投诉、舆情、供应商交付、产品质量、渠道反馈等多源数据，并通过统一风险事件模型进行存储和分析。

在 AI 驱动部分，我设计了完整的多 Agent 协作链路：意图理解 Agent 负责识别用户问题、时间范围和分析目标；数据检索 Agent 根据问题自动筛选相关风险数据；异常检测 Agent 对投诉量、负面情绪、供应链延迟、质量问题等指标进行识别；归因分析 Agent 按地区、产品、渠道、供应商等维度进行长链推理；建议 Agent 输出可执行的运营处理方案；报告 Agent 自动生成结构化风险分析报告。

项目核心成果是让用户不需要手写 SQL，也不需要人工整理大量数据，只需用自然语言提问，系统就能完成数据查询、异常识别、原因分析和报告生成。该项目体现了大数据多源治理、多 Agent 协作、长链推理、智能归因和 AI 决策辅助能力。

## 后续升级方向

- 接入 Kafka/Flink，把模拟风险事件升级为实时流式数据。
- 接入 ClickHouse，支持高并发 OLAP 查询。
- 接入大模型 API，让规则 Agent 升级为 LLM Agent。
- 接入企业微信、钉钉、邮件，实现高危风险自动通知。
- 接入 RAG，把企业制度、供应商合同、客服知识库作为归因依据。
